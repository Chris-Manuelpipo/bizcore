package com.bizcore.bizcore_backend.dto;

import com.bizcore.bizcore_backend.domain.Business;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;
import java.util.UUID;

public class BusinessDTO {

    private UUID id;

    @NotBlank(message = "Le nom du métier est obligatoire")
    private String name;

    @NotBlank(message = "Le domaine est obligatoire")
    private String domain;

    private String description;
    private String neededEducation;
    private String neededTraining;
    private String typeOfInvolvedActors;
    private String requiredJobProfiles;
    private LocalDateTime createdAt;
    private UUID tenantId;

    public BusinessDTO() {}

    public static BusinessDTO fromEntity(Business business) {
        BusinessDTO dto = new BusinessDTO();
        dto.setId(business.getId());
        dto.setName(business.getName());
        dto.setDomain(business.getDomain());
        dto.setDescription(business.getDescription());
        dto.setNeededEducation(business.getNeededEducation());
        dto.setNeededTraining(business.getNeededTraining());
        dto.setTypeOfInvolvedActors(business.getTypeOfInvolvedActors());
        dto.setRequiredJobProfiles(business.getRequiredJobProfiles());
        dto.setCreatedAt(business.getCreatedAt());
        if (business.getTenant() != null) {
            dto.setTenantId(business.getTenant().getId());
        }
        return dto;
    }

    public Business toEntity() {
        Business business = new Business();
        business.setName(this.name);
        business.setDomain(this.domain);
        business.setDescription(this.description);
        business.setNeededEducation(this.neededEducation);
        business.setNeededTraining(this.neededTraining);
        business.setTypeOfInvolvedActors(this.typeOfInvolvedActors);
        business.setRequiredJobProfiles(this.requiredJobProfiles);
        return business;
    }

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDomain() { return domain; }
    public void setDomain(String domain) { this.domain = domain; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getNeededEducation() { return neededEducation; }
    public void setNeededEducation(String neededEducation) { this.neededEducation = neededEducation; }

    public String getNeededTraining() { return neededTraining; }
    public void setNeededTraining(String neededTraining) { this.neededTraining = neededTraining; }

    public String getTypeOfInvolvedActors() { return typeOfInvolvedActors; }
    public void setTypeOfInvolvedActors(String typeOfInvolvedActors) { this.typeOfInvolvedActors = typeOfInvolvedActors; }

    public String getRequiredJobProfiles() { return requiredJobProfiles; }
    public void setRequiredJobProfiles(String requiredJobProfiles) { this.requiredJobProfiles = requiredJobProfiles; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public UUID getTenantId() { return tenantId; }
    public void setTenantId(UUID tenantId) { this.tenantId = tenantId; }
}
